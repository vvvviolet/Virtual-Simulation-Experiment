<!-- 5.软件工程经济学方法应用(大类)
包括: 软件项目净现值、IRR 与动态投资回收期实验、软件经济生命周期实验、单方案/软件产品经济性分析实验、多方案/多软件产品经济性分析实验、软件退出期计算实验等。 -->

<template>
    <RouterView></RouterView>
  </template>
  
  <script lang="ts">
    export default {
      name: 'Exp6',
    };
  </script>
  
  <style scoped lang="less"></style>