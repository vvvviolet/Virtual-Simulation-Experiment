<template>

</template>

<script lang="ts">
  export default {
    name: 'Exp5_dongtaitouzihuishou',
  };
</script>

<style scoped lang="less"></style>