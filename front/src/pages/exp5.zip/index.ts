import Exp5 from './Exp5.vue';
export default Exp5;
